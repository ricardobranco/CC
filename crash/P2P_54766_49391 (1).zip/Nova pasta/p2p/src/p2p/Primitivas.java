/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

/**
 *
 * @author User
 */
public class Primitivas {
    public String hello ="hello";
    public String get ="get";
    public String chunk ="chunk";
    public String status ="status";
}
