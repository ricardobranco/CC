/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.io.File;

/**
 *
 * @author User
 */
public class Status {
    Data dados;

    public Status(Data dados) {
        this.dados = dados;
    }

    public Data getDados() {
        return dados;
    }

    public void setDados(Data dados) {
        this.dados = dados;
    }
      public void status(){
        for(Vizinhos i : this.dados.getVizinhos()){
            System.out.println("IP "+ i.getIp() + " Porta "+ i.getPorta());
        }
        File i=new File(this.dados.dados.getPath()+"/stats.txt");
        System.out.println(i);
    }
}
