/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class StatusTest implements Runnable{
    Data data;

    public StatusTest(Data data) {
        this.data = data;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
    
    public void testStatus(){
        ArrayList<Vizinhos> novo=new ArrayList<Vizinhos>();
        ArrayList<Vizinhos> apagar= new ArrayList<Vizinhos>();
        for(Vizinhos v:this.data.vizinhos){
            byte [] hello= new byte[1024];
            byte [] receive=new byte[1024];
            hello=("hello,"+v.getIp()+":"+v.getPorta()).getBytes();
            DatagramPacket packet=new DatagramPacket(hello,hello.length,v.getIp(),v.getPorta());
            packet.setData(hello);
            try {
                DatagramSocket s= new DatagramSocket(v.getPorta());
                s.setSoTimeout(this.data.dados.getT2());
                try {
                    s.send(packet);
                    DatagramPacket receivepacket=new DatagramPacket(receive,receive.length);
                    s.receive(receivepacket); 
                    novo.add(v);
                    s.close();
                } catch (IOException ex) {
                    Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (SocketException ex) {
                Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
                apagar.add(v);
            }
        }      
        for(Vizinhos i:novo){
            if(this.data.vizinhos.contains(i)==false){
                this.data.vizinhos.add(i);
                System.out.println("Vizinho ip :"+ i.getIp()+ " : porta : " + i.getPorta());
            }
        }
        for(Vizinhos i:apagar){
            if(this.data.vizinhos.contains(i)==true){
                this.data.vizinhos.remove(i);
            }
        }
        
    }


    public void BroadCast(){
        System.out.println("A efectuar broadcast");
        //falta colocar o cenas a guardas mais que uma resposta;S
            try {
            byte [] hello= new byte[1024];
            InetAddress broadcast=InetAddress.getByName("255.255.255.255");
            Collection<InetAddress> res = getSelfIPs();   
            Iterator i=res.iterator();
            Object address=null;
            while(i.hasNext()) {
                address=i.next();
            }
            hello=(("hello")+","+address).getBytes();
                DatagramPacket packet=new DatagramPacket(hello,hello.length,broadcast,this.data.dados.getPorta());
                packet.setData(hello);
                try {
                    DatagramSocket s=new DatagramSocket();
                    s.setBroadcast(true);
                    s.setSoTimeout(this.data.dados.getT2()*15);
                    try {
                        s.send(packet);
                        DatagramPacket receivepacket=new DatagramPacket(hello,hello.length);
                        s.receive(receivepacket); 
                        this.data.vizinhos.add(new Vizinhos(receivepacket.getAddress(),receivepacket.getPort()));
                        s.close();                            
                    } catch (IOException ex) {
                        Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (SocketException ex) {
                    Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
                }
        } catch (UnknownHostException ex) {
                Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    	public static Collection<InetAddress> getSelfIPs(){
		Collection<InetAddress> res = new HashSet<InetAddress>();		
		Enumeration<NetworkInterface> e = null;
                
		try {
			e = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e1) {
			System.out.println("Exit (Main): Failed find own address.");
			System.exit(1);
		}
       while(e.hasMoreElements())
        {        	
            NetworkInterface n=(NetworkInterface) e.nextElement();
            Enumeration<InetAddress> ee = n.getInetAddresses();
            while(ee.hasMoreElements())
            {
                InetAddress i = (InetAddress) ee.nextElement();
               // System.out.println("One of my addresses is "+i.getHostAddress());
                if(Inet4Address.class.isInstance(i) && i.isLoopbackAddress() == false)
                {
                	//System.out.println("\tAnd I'm going to add it.");
                	res.add(i);
                }
         }
        }
        return res;
	}
    
    @Override
    public void run(){
        int i=0;
        while(true){
        try {
            Thread.sleep(this.data.dados.getT1()*1000);
            testStatus();
            System.out.println(i);
            i++;
            if(i==5){
              BroadCast();
              i=0;
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }
}

