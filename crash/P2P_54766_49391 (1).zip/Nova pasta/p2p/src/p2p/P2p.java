/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class P2p {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Reader r=new Reader();
            Data dados=new Data(r);
            Parser p=new Parser();
            StatusTest status=new StatusTest(dados);
            Thread t1=new Thread(status);
            t1.start();
            DatagramSocket serverSocket = new DatagramSocket(dados.dados.getPorta());
                byte[] receiveData = new byte[1024];
                while(true)
                   {
                      DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                      serverSocket.receive(receivePacket);
                      String sentence = new String( receivePacket.getData());
                      System.out.println("RECEIVED: " + sentence);
                      InetAddress IPAddress = receivePacket.getAddress();
                      int port = receivePacket.getPort();
                      String [] comando=sentence.split(",");
                      p.parser(comando[0],comando[1], IPAddress, port,receivePacket);
                      if(sentence.equals("shtdown"))break;
                   }
                serverSocket.close();
        } catch (SocketException ex) {
            Logger.getLogger(P2p.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(P2p.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
