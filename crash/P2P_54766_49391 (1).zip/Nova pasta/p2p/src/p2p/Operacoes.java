/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class Operacoes {

    
    public void hello(DatagramPacket packet){
        try {      
            byte [] hello=new byte[1024];
            hello="hello".getBytes();
            DatagramPacket packetresponde=new DatagramPacket(hello,hello.length,packet.getAddress(),packet.getPort());
            DatagramSocket s=new DatagramSocket();
            s.send(packetresponde);
            s.close();
        } catch (SocketException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    public void get(int socketP,InetAddress ip,int porta,String label,int size){     
        byte[] chunk=new byte[size];
        byte [] receive=new byte[size];
        String [] args;
            try {         
            RandomAccessFile raf =new RandomAccessFile("label", "rw");
            DatagramSocket s=new DatagramSocket(socketP);
            DatagramPacket receivepacket=new DatagramPacket(receive,receive.length);
            s.receive(receivepacket);
            args=(new String(receivepacket.getData())).split(",");
            chunk=chunk(raf,Integer.parseInt(args[1]),Integer.parseInt(args[2]));
            DatagramPacket sendpacket=new DatagramPacket(chunk,chunk.length);
            s.send(sendpacket);
            s.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }
    public byte[] chunk(RandomAccessFile raf,int offset,int size){
        byte [] chunk=new byte[size];
        try
       {           
            raf.read(chunk,offset, size);           
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
        return chunk;
    }
    
}
