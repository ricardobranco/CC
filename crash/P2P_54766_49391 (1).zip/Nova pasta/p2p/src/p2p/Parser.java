/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.net.DatagramPacket;
import java.net.InetAddress;

/**
 *
 * @author User
 */
public class Parser {
    public void parser(String comando,String args,InetAddress ip,int porta,DatagramPacket packet){
        Operacoes op=new Operacoes();
        if(comando.equals("hello")){
            op.hello(packet);
        }
        if(comando.equals("get")){
            
        }
        if(comando.equals("chunk")){
            
        }
        if(comando.equals("status")){
            
        }
    }
}
