/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class Transferencias {
    Data data;

    public Transferencias(Data dados) {
        this.data= dados;
    }

    public Data getDados() {
        return data;
    }

    public void setDados(Data dados) {
        this.data = dados;
    }
    
    public void transferencia(ArrayList<Vizinhos> peers,String label,int size){
        try {
            int x=0;
            int peersON=0;
            int w=(this.data.dados.getV()/size)*this.data.getDados().getK();//(chunks por tamanho * qntidade de peers)
            int offset=0;
            int sizeOffset=this.data.dados.getV()/size;
            File file=new File (this.data.dados.getPath()+"/"+"label");
            RandomAccessFile raf =new RandomAccessFile(file, "rw");
            for(Vizinhos i:peers){
                        while(peersON<this.data.getDados().getK() && offset!=size ){
                        byte [] get= new byte[1024];
                        byte [] chunk= new byte[1024];
                        byte [] receive=new byte[sizeOffset];
                        get=("get,"+i.getIp()+":"+i.getPorta() +label+size).getBytes();
                        DatagramPacket packet=new DatagramPacket(get,get.length,i.getIp(),i.getPorta());
                        packet.setData(get);
                        try {
                            DatagramSocket s= new DatagramSocket(i.getPorta());
                            s.setSoTimeout(this.data.dados.getT2());
                            try {
                                s.send(packet);
                                //pedir chunks!
                                for(x=0;x<this.data.dados.getV();x++){
                                    chunk=("chunk,"+i.getIp()+":"+i.getPorta() + ","+offset+","+sizeOffset).getBytes();
                                    DatagramPacket packet2=new DatagramPacket(chunk,chunk.length,i.getIp(),i.getPorta());
                                    packet2.setData(chunk);
                                     s.send(packet2);
                                   //receber chunks
                                    DatagramPacket receivepacket=new DatagramPacket(receive,receive.length);
                                    s.receive(receivepacket);
                                    raf.write(receivepacket.getData(),offset, sizeOffset);
                                    offset+=sizeOffset;
                                    //ESCREVE CHUNK NUM BUFFER OU O QUE FOR!
                                }
                                s.close();
                            } catch (IOException ex) {
                                Logger.getLogger(StatusTest.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        } catch (SocketException ex) {
                            this.data.vizinhos.remove(i);
                        }
                        peersON++;   
                    }                  
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Transferencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
