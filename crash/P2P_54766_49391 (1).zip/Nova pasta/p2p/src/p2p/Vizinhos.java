/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.net.InetAddress;

/**
 *
 * @author User
 */
public class Vizinhos {
    private InetAddress ip;
    private int porta;

    public Vizinhos(InetAddress ip, int porta) {
        this.ip = ip;
        this.porta = porta;
    }

    public InetAddress getIp() {
        return ip;
    }

    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }
    
}
