/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2p;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Data {
    Reader dados;
    List<Vizinhos> vizinhos;

    public Data(Reader dados) {
        this.dados = dados;
        this.vizinhos =new ArrayList<Vizinhos>();
    }

    
    
    public Reader getDados() {
        return dados;
    }

    public void setDados(Reader dados) {
        this.dados = dados;
    }

    public List<Vizinhos> getVizinhos() {
        return vizinhos;
    }

    public void setVizinhos(List<Vizinhos> vizinhos) {
        this.vizinhos = vizinhos;
    }
    
    
}
